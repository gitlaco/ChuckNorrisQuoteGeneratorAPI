﻿using System.Collections.Generic;
using System.Linq;
using System;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Net;
using System.Net.Http.Json;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows.Input;
using Windows.Media.Capture.Frames;
using Microsoft.Toolkit.Mvvm.ComponentModel;
using Microsoft.Toolkit.Mvvm.Input;
using QuotesGeneratorCN.Models;

namespace QuotesGeneratorCN.ViewModels
{
    public class MainPageViewModel : ObservableObject
    {

        public MainPageViewModel()
        {
            ClickForQuoteCommand = new RelayCommand(UpdateChuckNorrisQuote);
        }

        private void UpdateChuckNorrisQuote()
        {
            ChuckNorrisQuote quote = GetRandomQuote();
            CurrentChuckNorrisQuote = quote.value;
            PrevQuotes.Add(quote);
        }

        public static ChuckNorrisQuote GetRandomQuote()
        {
            string requestResponse = ""; // initialise response string
            using (WebClient wc = new WebClient())
            {
                requestResponse =
                    wc.DownloadString("https://api.chucknorris.io/jokes/random"); // fill response string
            }
            
            // deserialise string to chuck norris quote object
            ChuckNorrisQuote quote = JsonConvert.DeserializeObject<ChuckNorrisQuote>(requestResponse);
            return quote;
        }

        private ICommand clickForQuoteCommand;
        public ICommand ClickForQuoteCommand
        {
            get => clickForQuoteCommand;
            set
            {
                clickForQuoteCommand = value;
                this.OnPropertyChanged("ClickForQuoteCommand");
            }
        }

        private String currentChuckNorrisQuote = "Nothing";
        public String CurrentChuckNorrisQuote
        {
            get => currentChuckNorrisQuote;
            set
            {
                currentChuckNorrisQuote = value;
                //this.OnPropertyChanged(nameof(currentChuckNorrisQuote));
                this.OnPropertyChanged("CurrentChuckNorrisQuote");
            }
        }

        private ObservableCollection<ChuckNorrisQuote> prevQuotes = new ObservableCollection<ChuckNorrisQuote>();

        public ObservableCollection<ChuckNorrisQuote> PrevQuotes
        {
            get => prevQuotes;
            set
            {
                prevQuotes = value;
                this.OnPropertyChanged("PrevQuotes");
            }
        }

        private ChuckNorrisQuote getQuote() => GetRandomQuote();
    }
}
